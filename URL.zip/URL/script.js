console.log('Hello world');
$<"#short1"> .onlick = () =>{
    var x =document.getElementById("txtbox").Value;
    document.getElementById("txtbox1").value=x;
}
   $<#"btncopy">.onclick = () =>{
    document.getElementById("txtbox1").select();
    document.execCommand("copy");
}
